import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _0ffa03f2 = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _a973ea08 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _8498c628 = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _0f323b28 = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _b4950880 = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _2797b76c = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _419db48e = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _0ffa03f2,
    children: [{
      path: "",
      component: _a973ea08,
      name: "home"
    }, {
      path: "/login",
      component: _8498c628,
      name: "login"
    }, {
      path: "/register",
      component: _8498c628,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _0f323b28,
      name: "profile"
    }, {
      path: "/settings",
      component: _b4950880,
      name: "settings"
    }, {
      path: "/editor",
      component: _2797b76c,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _419db48e,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
